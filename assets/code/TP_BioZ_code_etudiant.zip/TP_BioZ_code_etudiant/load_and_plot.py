import numpy as np 
import matplotlib.pyplot as plt

fname= "my_measure.csv"

data = np.genfromtxt(fname, delimiter=',')
freq = np.transpose(data[:,0])
module = np.transpose(data[:,1])
argument = np.transpose(data[:,2])


plt.figure(1)
plt.subplot(211)
plt.loglog(freq, module, color='r', label='my measure')
plt.xlabel('Frequency ($Hz$)')
plt.ylabel('Impedance ($\Omega$)')
plt.legend()
plt.grid()
plt.subplot(212)
plt.semilogx(freq,argument, color='r')
plt.grid()
plt.xlabel('Frequency ($Hz$)')
plt.ylabel('Phase ($°$)')
plt.tight_layout()

plt.show()