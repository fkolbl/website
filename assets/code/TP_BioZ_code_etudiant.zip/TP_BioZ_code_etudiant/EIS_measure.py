"""
    Python script to perform Potentiostat EIS with BIMMS.
    Authors: Florian Kolbl / Louis Regnacq / Thomas Couppey
    (c) ETIS - University Cergy-Pontoise
        IMS - University of Bordeaux
        CNRS
    Requires:
        Python 3.6 or higher
        Analysis_Instrument - class handling Analog Discovery 2 (Digilent)
"""
import bimms as bm
import numpy as np
import matplotlib.pyplot as plt

fmin = 100            		#Start Frequency (Hz)
fmax = 10e6            		#Stop Frequency (Hz)
n_pts = 200           		#Number of frequency points
V_stim = 100              	#amplitude (mV)
settling_time = 0.01   		#Settling time between points
NPeriods = 32          		#Number of period per frequency points
DUT_connection = "2_WIRE"   #Connection to the DUT mode: 2_WIRE or 4_WIRE
Gain_IRO = 10				#Current readout gain
Gain_VRO = 10				#Voltage readout gain

fname = 'my_measure.csv'	#output file name

BS = bm.BIMMS()				#open connection to bimms

#BIMMS configuration
BS.config.excitation_mode("P_EIS")			#voltage mode excitation
BS.config.wire_mode(DUT_connection)
BS.config.excitation_signaling_mode("SE")	#Single-ended excitation
BS.config.excitation_coupling("DC")			#DC coupling
BS.config.IRO_gain(Gain_IRO)
BS.config.VRO_gain(Gain_VRO)
BS.config.V_amplitude = V_stim 


m1 = bm.EIS(fmin=fmin,fmax=fmax,n_pts=n_pts,settling_time=settling_time,NPeriods=NPeriods)
BS.attach_measure(m1)
results = BS.measure()
del BS

freq = results['freq']
mag_Z = results['mag_Z']
phase_Z = results['phase_Z']


#dump data to csv
data = np.asarray([freq,mag_Z,phase_Z])
data = np.transpose(data)
np.savetxt(fname, data, delimiter=",")

# plot results
plt.figure(1)
plt.subplot(211)
plt.loglog(freq,mag_Z)
plt.xlabel('Frequency ($Hz$)')
plt.ylabel('Impedance ($\Omega$)')
plt.grid()
plt.subplot(212)
plt.semilogx(freq,phase_Z)
plt.grid()
plt.xlabel('Frequency ($Hz$)')
plt.ylabel('Phase ($°$)')
plt.tight_layout()
plt.show()