import numpy as np 
import matplotlib.pyplot as plt
import scipy.optimize as opt

fname = "my_measure.csv"

data = np.genfromtxt(fname, delimiter=',')
freq = np.transpose(data[:,0])
module = np.transpose(data[:,1])
argument = np.transpose(data[:,2])

def RCR_model(freq, Re, Cm, Ri):
    Zeq = ____________________________
    mod = ____________________________
    arg = ____________________________
    return freq, mod, arg

def RCR_model_fit(freq, Re, Cm, Ri):
    _, mod, _ = RCR_model(freq, Re, Cm, Ri)
    return mod

popt, pcov = opt.curve_fit(RCR_model_fit, freq, module, p0=[1e3, 1e-8, 50])

freq_fit, mod_fit, arg_fit = RCR_model(freq, popt[0], popt[1], popt[2])

plt.figure(1)
plt.subplot(211)
plt.loglog(freq, module, color='b', label='4 points')
plt.loglog(freq_fit, mod_fit, color='k', label='model fit')
plt.xlabel('Frequency ($Hz$)')
plt.ylabel('Impedance ($\Omega$)')
plt.legend()
plt.grid()
plt.subplot(212)
plt.semilogx(freq,argument, color='b')
plt.semilogx(freq_fit,arg_fit, color='k')
plt.grid()
plt.xlabel('Frequency ($Hz$)')
plt.ylabel('Phase ($°$)')
plt.tight_layout()

plt.show()